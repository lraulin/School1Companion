﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace BooksCompanion
{

    public class Book
    {
        #region Properties
        private int _BookID;
        private string _BookTitle;
        private string _AuthorName;
        private int _Length;
        private bool _IsOnAmazon;
        private string _DateCreated;

        public int BookID
        {
            get
            {
                return this._BookID;
            }

            set
            {
                this._BookID = value;
            }
        }

        public string BookTitle
        {
            get
            {
                return this._BookTitle;
            }

            set
            {
                this._BookTitle = value;
            }
        }

        public string AuthorName
        {
            get
            {
                return this._AuthorName;
            }

            set
            {
                this._AuthorName = value;
            }
        }

        public int Length
        {
            get
            {
                return this._Length;
            }

            set
            {
                this._Length = value;
            }
        }

        public bool IsOnAmazon
        {
            get
            {
                return this._IsOnAmazon;
            }

            set
            {
                this._IsOnAmazon = value;
            }
        }

        public string DateCreated
        {
            get
            {
                return this._DateCreated;
            }

            set
            {
                this._DateCreated = value;
            }
        }
        #endregion Properties

        public Book()
        {

        }

        public Book(string sCnxn, string sLogPath, int iBookID)
        {
            try
            {
                SqlConnection oCnxn = new SqlConnection(sCnxn);

                SqlCommand oCmd = new SqlCommand();
                oCmd.Connection = oCnxn;
                oCmd.CommandText = "spBookByID";
                oCmd.CommandType = CommandType.StoredProcedure;
                oCmd.Parameters.Add("@BookID", SqlDbType.Int).Value = iBookID;

                oCnxn.Open();
                SqlDataReader oReader = oCmd.ExecuteReader();
                while (oReader.Read())
                {
                    this._BookID = iBookID;
                    this._BookTitle = oReader["BookTitle"].ToString();
                    this._AuthorName = oReader["AuthorName"].ToString();
                    this._Length = Convert.ToInt32(oReader["Length"]);
                    this._IsOnAmazon = Convert.ToBoolean(oReader["IsOnAmazon"]);
                    this._DateCreated = oReader["DateCreated"].ToString();
                }
                oCnxn.Close();
            }
            catch (Exception ex)
            {
                Log oLog = new Log();
                oLog.LogError("BooksConstructor", ex.Message, sLogPath);
            }
        }

        public bool Save(string sCnxn, string sLogPath)
        {
            try
            {
                SqlConnection oCnxn = new SqlConnection(sCnxn);

                SqlCommand oCmd = new SqlCommand();
                oCmd.Connection = oCnxn;
                oCmd.CommandText = "spBookSave";
                oCmd.CommandType = CommandType.StoredProcedure;

                oCmd.Parameters.Add("@BookTitle", SqlDbType.NVarChar, 50).Value = this._BookTitle;
                oCmd.Parameters.Add("@AuthorName", SqlDbType.NVarChar, 50).Value = this._AuthorName;
                oCmd.Parameters.Add("@Length", SqlDbType.Int).Value = this._Length;
                oCmd.Parameters.Add("@IsOnAmazon", SqlDbType.Bit).Value = this._IsOnAmazon;
                oCmd.Parameters.Add("@BookID", SqlDbType.Int).Value = this._BookID;

                oCnxn.Open();
                oCmd.ExecuteNonQuery();
                oCnxn.Close();

                return true;
            }
            catch (Exception ex)
            {
                Log oLog = new Log();
                oLog.LogError("BookList", ex.Message, sLogPath);
                return false;
            }
        }
    }
}
